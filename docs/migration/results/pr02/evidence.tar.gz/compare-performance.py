import json, statistics
from pathlib import Path
root = Path(__file__).resolve().parent
baseline = Path("docs/migration/results/2026-10-31-clean")
out = {}
for family in ["gpu", "throughput"]:
    versions = {}
    for version, directory in [("pr01", baseline), ("pr02", root)]:
        data = json.loads((directory / (family + ".json")).read_text())
        groups = {}
        for mode in ["graphics", "compute"]:
            rows = [r for r in data["benchmarks"] if r.get("run_type") == "iteration" and "/" + mode + "/" in r["name"]]
            assert len(rows) == 5, (family, version, mode, len(rows))
            assert all(r["iterations"] == 4 and not r.get("error_occurred") for r in rows)
            if family == "gpu":
                assert all(r["gpu.samples"] == 256 for r in rows)
                assert all(v == 256 for r in rows for k,v in r.items() if k.endswith(".samples"))
                metrics = {k: statistics.median(r[k] for r in rows) for k in rows[0] if k.startswith("gpu.") and (k.endswith("median_ms") or k.endswith("p95_ms"))}
            else:
                metrics = {"fps": statistics.median(r["fps"] for r in rows), "benchmark_thread_cpu_ms_per_frame": statistics.median(r["cpu_time"] / 64 for r in rows)}
            metrics["frames_per_repetition"] = 256
            groups[mode] = metrics
        versions[version] = {"context": data["context"], "modes": groups}
    deltas = {}
    for mode in ["graphics", "compute"]:
        a,b = (versions[v]["modes"][mode] for v in ["pr01", "pr02"])
        deltas[mode] = {k: (b[k] / a[k] - 1) * 100 for k in a if k != "frames_per_repetition" and a[k]}
    out[family] = {"versions": versions, "delta_percent": deltas}
(root / "performance-comparison.json").write_text(json.dumps(out, indent=2) + "\n")
for family in out:
    for mode in ["graphics", "compute"]:
        metrics = out[family]["versions"]["pr02"]["modes"][mode]
        print(family, mode, metrics)
        print("delta percent", out[family]["delta_percent"][mode])
